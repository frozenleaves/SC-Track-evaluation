library(tidyverse)
library(cowplot)

mot <- read_csv("ENTER_DIVISION_THRESHOLD/IDF1_mota_score.csv")
mot_long <- pivot_longer(data = mot, cols = c(2:7), names_to = "div_threshold", values_to = "value")
colnames(mot_long)[1] <- "metric"
mot_long$div_threshold <- as.character(mot_long$div_threshold)
mot_long$div_threshold <- factor(mot_long$div_threshold, levels = unique(mot_long$div_threshold))

figA_copy <- ggplot(data = mot_long[mot_long$metric == "IDF1", ], aes(x = div_threshold, y = value, colour = cell_line, group = cell_line)) +
  geom_line() +
  geom_point() +
  labs(x = "Division Threshold", y = "IDF1 value") + 
  theme_bw() +
  theme(legend.key.size = unit(1, "cm"),
        legend.title = element_text(size=12),
        legend.text = element_text(size=10)) +
  guides(colour = guide_legend(title = "Cell Line"))

legend <- get_legend(figA_copy)

figA <- ggplot(data = mot_long[mot_long$metric == "IDF1", ], aes(x = div_threshold, y = value, colour = cell_line, group = cell_line)) +
  geom_line(show.legend = FALSE) +
  geom_point(show.legend = FALSE) +
  labs(x = "Division Threshold", y = "IDF1 value") + 
  theme_bw()

figB <- ggplot(data = mot_long[mot_long$metric == "MOTA", ], aes(x = div_threshold, y = value, colour = cell_line, group = cell_line)) +
  geom_line(show.legend = FALSE) +
  geom_point(show.legend = FALSE) +
  labs(x = "Division Threshold", y = "MOTA value") + 
  theme_bw()

cdf <- read_csv("ENTER_DIVISION_THRESHOLD/CDF1_score.csv")
cdf_long <- pivot_longer(data = cdf, cols = c(2:7), names_to = "div_threshold", values_to = "value")
colnames(cdf_long)[1] <- "metric"
cdf_long$div_threshold <- as.character(cdf_long$div_threshold)
cdf_long$div_threshold <- factor(cdf_long$div_threshold, levels = unique(cdf_long$div_threshold))

figC <- ggplot(data = cdf_long, aes(x = div_threshold, y = value, colour = cell_line, group = cell_line)) +
  geom_line(show.legend = FALSE) +
  geom_point(show.legend = FALSE) +
  labs(x = "Division Threshold", y = "CDF1 value") + 
  theme_bw()

plot_grid(figA, figB, figC, legend,
          labels = c("A", "B", "C", ""))
ggsave2(filename = "supplementary_figures/fig_s1.pdf", width = 8, height = 6, units = "in")
