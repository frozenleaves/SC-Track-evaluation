library(tidyverse)
library(cowplot)


idf_mota <- read_csv("AVAILABLE_RANGE_COEFFICIENT/IDF1_MOTA_score.csv")
idf_mota_long <- pivot_longer(data = idf_mota, cols = c(2:6), names_to = "range_coefficient", values_to = "value")
colnames(idf_mota_long)[1] <- "metric"
colnames(idf_mota_long)[2] <- "cell_line"

figA_copy <- ggplot(data = idf_mota_long[idf_mota_long$metric == "IDF1", ], aes(x = range_coefficient, y = value, colour = cell_line, group = cell_line)) +
  geom_line() +
  geom_point() +
  labs(x = "Range Coefficient", y = "IDF1 value") + 
  theme_bw() +
  theme(legend.key.size = unit(1, "cm"),
        legend.title = element_text(size=12),
        legend.text = element_text(size=10)) +
  guides(colour = guide_legend(title = "Cell Line"))

legend <- get_legend(figA_copy)

figA <- ggplot(data = idf_mota_long[idf_mota_long$metric == "IDF1", ], aes(x = range_coefficient, y = value, colour = cell_line, group = cell_line)) +
  geom_line(show.legend = FALSE) +
  geom_point(show.legend = FALSE) +
  labs(x = "Range Coefficient", y = "IDF1 value") + 
  theme_bw()

figB <- ggplot(data = idf_mota_long[idf_mota_long$metric == "MOTA", ], aes(x = range_coefficient, y = value, colour = cell_line, group = cell_line)) +
  geom_line(show.legend = FALSE) +
  geom_point(show.legend = FALSE) +
  labs(x = "Range Coefficient", y = "MOTA value") + 
  theme_bw()


cdf <- read_csv("AVAILABLE_RANGE_COEFFICIENT/CDF1_score.csv")
cdf_mota_long <- pivot_longer(data = cdf, cols = c(2:6), names_to = "range_coefficient", values_to = "value")
colnames(cdf_mota_long)[1] <- "metric"
colnames(cdf_mota_long)[2] <- "cell_line"

figC <- ggplot(data = cdf_mota_long, aes(x = range_coefficient, y = value, colour = cell_line, group = cell_line)) +
  geom_line(show.legend = FALSE) +
  geom_point(show.legend = FALSE) +
  labs(x = "Range Coefficient", y = "CDF1 value") + 
  theme_bw()

plot_grid(figA, figB, figC, legend,
          labels = c("A", "B", "C", ""))
ggsave2(filename = "supplementary_figures/fig_s2.pdf", width = 8, height = 6, units = "in")
