library(tidyverse)
library(cowplot)
library(RColorBrewer)


df1 <- read_csv("Figure 4/diff_time_resolution_idf1-raw-new.csv")
colnames(df1)[1] <- "Time"
df1 <- pivot_longer(df1, cols = !Time, names_to = "Tracker", values_to = "IDF1") 
df1$Time <- factor(as.character(df1$Time), levels = c("5", "10", "15", "20"))
df1$Tracker <- factor(df1$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate", "Deepcell-tracking"))

figA_copy <- ggplot(data = df1, aes(x = Time, y = IDF1, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = TRUE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = TRUE, aes(colour = Tracker)) + 
  theme_classic() +
  theme(legend.key.size = unit(1, "cm"),
        legend.title = element_text(size=12),
        legend.text = element_text(size=10))
figA_copy

figA <- ggplot(data = df1, aes(x = Time, y = IDF1, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = FALSE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = FALSE, aes(colour = Tracker)) + 
  theme_classic() +
  theme(
    legend.position = c(.3, .4),
    legend.justification = c("right", "top"),
    legend.box.just = "right",
    legend.margin = margin(6, 6, 6, 6)
  ) +
  xlab("Time (min)")
figA


legend <- get_legend(figA_copy)

df2 <- read_csv("Figure 4/diff_time_resolution_mota-raw-new.csv")
colnames(df2)[1] <- "Time"
df2 <- pivot_longer(df2, cols = !Time, names_to = "Tracker", values_to = "MOTA") 
df2$Time <- factor(as.character(df2$Time), levels = c("5", "10", "15", "20"))
df2$Tracker <- factor(df2$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate", "Deepcell-tracking"))

figB <- ggplot(data = df2, aes(x = Time, y = MOTA, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = FALSE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = FALSE, aes(colour = Tracker)) + 
  theme_classic()  +
  xlab("Time (min)") 

df3 <- read_csv("Figure 4/CDF1-diff-time-raw-new-group.csv")
colnames(df3)[1] <- "Time"
df3 <- pivot_longer(df3, cols = !Time, names_to = "Tracker", values_to = "CDF1") 
df3$Time <- factor(as.character(df3$Time), levels = c("5", "10", "15", "20"))
df3$Tracker <- factor(df3$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate"))

figC <- ggplot(data = df3, aes(x = Time, y = CDF1, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = FALSE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = FALSE, aes(colour = Tracker)) + 
  theme_classic() +
  xlab("Time (min)")

plot_grid(figA, figB, figC, legend,
          labels = c("A", "B", "C", ""))

ggsave2(filename = "Figure 4/fig4.pdf", width = 8, height = 6, units = "in")
