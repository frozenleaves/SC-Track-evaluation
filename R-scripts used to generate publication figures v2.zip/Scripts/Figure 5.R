library(tidyverse)
library(cowplot)
library(RColorBrewer)


df1 <- read_csv("Figure 5/diff_loss_idf1-raw-new.csv")
colnames(df1)[1] <- "Loss"
df1 <- pivot_longer(df1, cols = !Loss, names_to = "Tracker", values_to = "IDF1") 
df1$Loss <- factor(as.character(df1$Loss), levels = c("0", "0.05", "0.1", "0.2", "0.3", "0.5"))
df1$Tracker <- factor(df1$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate", "Deepcell-tracking"))

figA_copy <- ggplot(data = df1, aes(x = Loss, y = IDF1, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = TRUE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = TRUE, aes(colour = Tracker)) + 
  theme_classic() +
  theme(legend.key.size = unit(1, "cm"),
        legend.title = element_text(size=12),
        legend.text = element_text(size=10))
figA_copy

figA <- ggplot(data = df1, aes(x = Loss, y = IDF1, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = FALSE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = FALSE, aes(colour = Tracker)) + 
  theme_classic() +
  xlab("Segmentation Loss (fraction)")
figA


legend <- get_legend(figA_copy)

df2 <- read_csv("Figure 5/diff_loss_mota-raw-new.csv")
colnames(df2)[1] <- "Loss"
df2 <- pivot_longer(df2, cols = !Loss, names_to = "Tracker", values_to = "MOTA") 
df2$Loss <- factor(as.character(df2$Loss), levels = c("0", "0.05", "0.1", "0.2", "0.3", "0.5"))
df2$Tracker <- factor(df2$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate", "Deepcell-tracking"))

figB <- ggplot(data = df2, aes(x = Loss, y = MOTA, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = FALSE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = FALSE, aes(colour = Tracker)) + 
  theme_classic() +
  xlab("Segmentation Loss (fraction)")
figB

df3 <- read_csv("Figure 5/CDF1-diff-loss-raw-new-group.csv")
colnames(df3)[1] <- "Loss"
df3 <- pivot_longer(df3, cols = !Loss, names_to = "Tracker", values_to = "CDF1") 
df3$Loss <- factor(as.character(df3$Loss), levels = c("0", "0.05", "0.1", "0.2", "0.3", "0.5"))
df3$Tracker <- factor(df3$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate"))

figC <- ggplot(data = df3, aes(x = Loss, y = CDF1, fill = Tracker)) + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_boxplot(outlier.shape = NA, show.legend = FALSE) +
  geom_point(alpha = 0.5, position = position_jitterdodge(jitter.width = 0.2, seed = 1), show.legend = FALSE, aes(colour = Tracker)) + 
  theme_classic() +
  xlab("Segmentation Loss (fraction)")

plot_grid(figA, figB, figC, legend,
          labels = c("A", "B", "C", ""))

ggsave2(filename = "Figure 5/fig5.pdf", width = 8, height = 6, units = "in")
