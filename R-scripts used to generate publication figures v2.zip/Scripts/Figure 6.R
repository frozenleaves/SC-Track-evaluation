library(tidyverse)
library(RColorBrewer)
library(readxl)

make_df <- function(file_string, tracker) {
  df <- read_xlsx(file_string)
  df <- df[,c(1:4)]
  colnames(df) <- c("Frames", rep(tracker, 3))
  df <- pivot_longer(df, cols = !Frames, names_to = "Tracker", values_to = "Time") %>%
    mutate(Speed = Frames / Time)
  
  df
}

pcna.df <- make_df(file_string = "Figure 6/runtime-pcnadeep.xlsx", tracker = "pcnaDeep")
sctrack.df <- make_df(file_string = "Figure 6/runtime-SCTrack_new.xlsx", tracker = "SC-Track")
trackmate.df <- make_df(file_string = "Figure 6/runtime-trackMate.xlsx", tracker = "TrackMate")
deepcell.df <- make_df(file_string = "Figure 6/deepcell-runtime.xlsx", tracker = "Deepcell-tracking")

merged.df <- bind_rows(pcna.df, sctrack.df, trackmate.df, deepcell.df)

summary.df <- merged.df %>%
  group_by(Frames, Tracker) %>%
  summarise(mean.speed = mean(Speed),
            sd.speed = sd(Speed),
            n.speed = n()) %>%
  mutate(se.speed = sd.speed / sqrt(n.speed),
         lower.ci.speed = mean.speed - qt(1 - (0.05 / 2), n.speed - 1) * se.speed,
         upper.ci.speed = mean.speed + qt(1 - (0.05 / 2), n.speed - 1) * se.speed)



summary.df$Tracker <- factor(summary.df$Tracker, levels = c("SC-Track", "pcnaDeep", "TrackMate", "Deepcell-tracking"))
summary.df$Frames <- factor(as.character(summary.df$Frames), levels = c("50", "100", "200", "300", "400", "500"))


ggplot(summary.df, aes(x = Frames, y = mean.speed, group = Tracker, colour = Tracker, fill = Tracker)) + 
  geom_line() + 
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Dark2") +
  geom_ribbon(aes(ymin = lower.ci.speed, ymax = upper.ci.speed),
              linetype = "blank",
              alpha = 0.1) +
  theme_classic() +
  theme(legend.key.size = unit(1, "cm"),
        legend.title = element_text(size=12),
        legend.text = element_text(size=10)) +
  ylab("Processing speed (frames/s)") +
  xlab("Number of frames")

ggsave(filename = "Figure 6/fig6.pdf", width = 7, height = 5, units = "in")
